BobStory UI v0.2
- Home Screen
- Universe Browser
- Responsive HTML/CSS/JS
Upload all files to GitHub Pages and open index.html