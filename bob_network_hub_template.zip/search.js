const searchBox=document.getElementById("search");
const result=document.getElementById("result");
fetch("agents.json")
.then(r=>r.json())
.then(agents=>{
 function render(keyword=""){
 result.innerHTML="";
 const filtered=agents.filter(a=>a.name.toLowerCase().includes(keyword.toLowerCase())||a.tags.some(t=>t.toLowerCase().includes(keyword.toLowerCase())));
 filtered.forEach(agent=>{const li=document.createElement("li"); const a=document.createElement("a"); a.href=agent.url; a.textContent=agent.name; a.target="_blank"; li.appendChild(a); result.appendChild(li);});
 }
 searchBox.addEventListener("input",e=>render(e.target.value));
 render();
});