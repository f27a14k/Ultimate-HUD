export class CharacterMemory {
  constructor(){ this.characters = JSON.parse(localStorage.getItem("characters")||"{}"); }
  save(){ localStorage.setItem("characters", JSON.stringify(this.characters)); }
  create(id,data){ this.characters[id]=data; this.save(); }
  get(id){ return this.characters[id]; }
  update(id,patch){ this.characters[id]={...this.characters[id],...patch}; this.save(); }
}
export const characterMemory=new CharacterMemory();