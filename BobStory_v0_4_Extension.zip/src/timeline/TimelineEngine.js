import {eventRegistry} from "../events/EventRegistry.js";
export class TimelineEngine{
 createWorldEvent(type,year){
 const ev={id:crypto.randomUUID(),type,year,status:"ACTIVE",createdAt:Date.now()};
 eventRegistry.add(ev);
 return ev;
 }
 getActiveEvents(){ return eventRegistry.active(); }
}
export const timeline=new TimelineEngine();