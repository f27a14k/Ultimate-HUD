export class EventRegistry {
 constructor(){ this.events=JSON.parse(localStorage.getItem("events")||"[]"); }
 save(){ localStorage.setItem("events",JSON.stringify(this.events)); }
 add(event){ this.events.push(event); this.save(); }
 list(){ return this.events; }
 active(){ return this.events.filter(e=>e.status!=="COMPLETED"); }
}
export const eventRegistry=new EventRegistry();