BobStory v0.4 Extension

Added Modules:
1. CharacterMemory
- remembers characters across browser sessions
- stores goals, trust, fear, inventory

2. EventRegistry
- stores world events
- tracks ACTIVE/COMPLETED events

3. TimelineEngine
- creates timeline events
- queries active events

Integration target:
Runtime v0.3
Universe -> Timeline -> EventRegistry -> Story Director
CharacterMemory -> Story Generator
