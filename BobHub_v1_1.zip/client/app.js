const log=t=>document.getElementById('log').textContent+=t+'\n';
const ws=new WebSocket('ws://localhost:8080');
const peers={}; let myId=''; let dc;
const rtc={iceServers:[{urls:'stun:stun.l.google.com:19302'}]};
ws.onmessage=async e=>{const m=JSON.parse(e.data);
if(m.type==='welcome'){myId=m.id;id.textContent=myId;}
if(m.type==='peers'){const ul=document.getElementById('peers'); ul.innerHTML=''; m.peers.filter(p=>p!==myId).forEach(p=>{let li=document.createElement('li'); li.innerText=p; li.onclick=()=>startPeer(p); ul.appendChild(li);});}
if(m.type==='offer'){const pc=new RTCPeerConnection(rtc); peers[m.from]=pc; pc.ondatachannel=ev=>{dc=ev.channel; dc.onmessage=x=>log('Peer:'+x.data)}; pc.onicecandidate=c=>{if(!c.candidate) ws.send(JSON.stringify({type:'answer',to:m.from,answer:pc.localDescription}));}; await pc.setRemoteDescription(m.offer); const ans=await pc.createAnswer(); await pc.setLocalDescription(ans);}
if(m.type==='answer'){const pc=peers[m.from]; await pc.setRemoteDescription(m.answer);} };
async function startPeer(target){const pc=new RTCPeerConnection(rtc); peers[target]=pc; dc=pc.createDataChannel('chat'); dc.onmessage=e=>log('Peer:'+e.data); pc.onicecandidate=e=>{if(!e.candidate) ws.send(JSON.stringify({type:'offer',to:target,offer:pc.localDescription}));}; const offer=await pc.createOffer(); await pc.setLocalDescription(offer);} 
function sendMsg(){if(dc){dc.send(msg.value);log('Me:'+msg.value)}}