# BobStory Prototype

ไฟล์:
- index.html : หน้าเว็บหลัก
- app.js : ตัวอย่าง Story Engine ฝั่ง Browser
- architecture.txt : สถาปัตยกรรมระบบ

แนวคิด:
Browser -> Story Gateway -> Universe Engine -> AI Layer -> Analytics

Prototype นี้ยังไม่มี AI จริง เป็นโครงสร้างเริ่มต้นสำหรับอัปโหลด GitHub Pages
