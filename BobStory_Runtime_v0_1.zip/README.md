# BobStory Runtime v0.1

ทำงานได้บน GitHub Pages

มี:
- Universe Engine
- Character Engine
- Story Director
- Rule-Based Story Generator
- Local Storage Memory

การใช้งาน:
1. แตก zip
2. อัปโหลดขึ้น GitHub
3. เปิด GitHub Pages
4. กดสร้างตอนใหม่

ข้อมูลโลกจะถูกบันทึกใน browser ผ่าน localStorage
