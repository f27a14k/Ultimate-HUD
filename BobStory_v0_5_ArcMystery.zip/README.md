# BobStory v0.5 Addon

ArcEngine
- createArc(name,description)
- active()
- updateProgress(id,progress)
- list()

MysteryRegistry
- create(question,episode)
- open()
- resolve(id,answer)
- all()

ตัวอย่างการใช้งาน
const arc=arcEngine.createArc("Missing King","ตามหาราชาที่หายตัว")
const mys=mysteryRegistry.create("ราชาหายไปไหน",1)
