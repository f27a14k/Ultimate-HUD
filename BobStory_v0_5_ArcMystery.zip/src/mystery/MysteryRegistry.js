export class MysteryRegistry {
 constructor(){ this.items=JSON.parse(localStorage.getItem("mysteries")||"[]"); }
 save(){ localStorage.setItem("mysteries",JSON.stringify(this.items)); }
 create(question,episode){ const m={id:crypto.randomUUID(),question,introducedEpisode:episode,resolved:false,createdAt:Date.now()}; this.items.push(m); this.save(); return m; }
 resolve(id,answer){ const m=this.items.find(x=>x.id===id); if(m){m.resolved=true;m.answer=answer;this.save();} return m; }
 open(){ return this.items.filter(x=>!x.resolved); }
 all(){ return this.items; }
}
export const mysteryRegistry=new MysteryRegistry();