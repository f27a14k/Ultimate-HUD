export class ArcEngine {
 constructor(){ this.arcs=JSON.parse(localStorage.getItem("arcs")||"[]"); }
 save(){ localStorage.setItem("arcs",JSON.stringify(this.arcs)); }
 createArc(name,description){ const arc={id:crypto.randomUUID(),name,description,status:"ACTIVE",progress:0,createdAt:Date.now()}; this.arcs.push(arc); this.save(); return arc; }
 list(){ return this.arcs; }
 updateProgress(id,p){ const a=this.arcs.find(x=>x.id===id); if(a){a.progress=p; if(p>=100)a.status='COMPLETED'; this.save();} return a; }
 active(){ return this.arcs.filter(a=>a.status==='ACTIVE'); }
}
export const arcEngine=new ArcEngine();