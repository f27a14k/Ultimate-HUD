export function createEpisode(g,year){return `แนว ${g}
ปี ${year}

ปริศนาใหม่ปรากฏขึ้นในเมือง และทุกคนเชื่อมโยงกับการหายตัวไปของราชา

[Cliffhanger] มีคนพบทางเข้าห้องลับใต้เมือง`;}