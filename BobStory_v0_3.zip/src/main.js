import {DB} from './core/storage.js';
import {createEpisode} from './engine/story.js';
let state=DB.load();
const el=document.getElementById('app');
window.app={
showHome(){el.innerHTML=`<div class="card"><h2>🔥 Trending</h2><p>The Missing King</p></div><div class="card"><h2>🎧 Continue</h2><p>Episodes: ${state.episodes.length}</p></div>`},
showUniverses(){el.innerHTML=`<div class="card"><h2>🌍 Fantasy Universe</h2><p>Year ${state.year}</p><button id="gen">สร้างตอนใหม่</button></div>`;document.getElementById('gen').onclick=()=>{const ep=createEpisode('Mystery',state.year);state.episodes.push(ep);state.year++;DB.save(state);app.showPlayer();}},
showPlayer(){const last=state.episodes[state.episodes.length-1]||'ยังไม่มีตอน';el.innerHTML=`<div class="card"><h2>📖 Story Player</h2>${last}</div>`}
};app.showHome();