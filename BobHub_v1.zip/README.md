Bob Hub v1

Architecture:
Browser -> Signaling Hub(WebSocket) -> Peer Discovery.

Run:
cd server
npm install
node server.js

Open client/index.html in browser.
