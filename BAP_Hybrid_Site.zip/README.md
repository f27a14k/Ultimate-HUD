BAP Hybrid Demo

Architecture:
Hub (discovery) + WebRTC (peer communication).
Open site in two browsers, exchange offer/answer JSON manually, then chat peer-to-peer.
