let pc=new RTCPeerConnection();
let dc;
const log=(m)=>document.getElementById("log").innerHTML+=m+"<br>";
pc.onicecandidate=e=>{if(!e.candidate){document.getElementById('signal').value=JSON.stringify(pc.localDescription)}};
pc.ondatachannel=e=>{dc=e.channel;setupChannel();};
function setupChannel(){dc.onmessage=e=>log('Peer: '+e.data);dc.onopen=()=>log('Connected');}
async function createOffer(){dc=pc.createDataChannel('chat');setupChannel();const offer=await pc.createOffer();await pc.setLocalDescription(offer);}
async function createAnswer(){const offer=JSON.parse(document.getElementById('signal').value);await pc.setRemoteDescription(offer);const answer=await pc.createAnswer();await pc.setLocalDescription(answer);}
async function acceptAnswer(){const answer=JSON.parse(document.getElementById('signal').value);await pc.setRemoteDescription(answer);}
function sendMsg(){if(dc&&dc.readyState==='open'){const m=document.getElementById('msg').value;dc.send(m);log('Me: '+m);}}
