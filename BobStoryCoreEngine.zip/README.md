# BobStory Core Engine v1

นี่คือ Core Engine ชุดแรกที่ใช้งานได้จริงบน Browser

ประกอบด้วย
- EventBus: ระบบส่ง Event ระหว่างโมดูล
- StateManager: เก็บสถานะกลางของโลก
- Validator: ตรวจสอบข้อมูลก่อนเข้าสู่ระบบ
- Scheduler: งานตามเวลา
- UniverseEngine: จัดการเหตุการณ์ของโลก

ทดสอบ:
1. อัปโหลดขึ้น GitHub Pages
2. เปิด index.html
3. กด Create Event
4. จะเห็น WORLD_EVENT ถูกสร้างและส่งผ่าน EventBus

Engine นี้จะเป็นฐานให้ Character Engine, Story Director และ Story Generator ในขั้นต่อไป
