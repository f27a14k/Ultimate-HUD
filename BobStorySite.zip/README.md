# BobStory Prototype

Structure:
- index.html : entry page
- assets/style.css : styles
- src/app.js : frontend bootstrap
- src/director.js : Story Director module
- src/universe.js : Universe Engine module
- api/openapi.yaml : API starter spec

Upload all files to GitHub Pages and open index.html.
